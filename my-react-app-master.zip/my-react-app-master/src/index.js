import React from 'react';
import ReactDOM from 'react-dom';
import Root from './router/index'


ReactDOM.render(
    <Root/>,

    document.getElementById('app')
);
